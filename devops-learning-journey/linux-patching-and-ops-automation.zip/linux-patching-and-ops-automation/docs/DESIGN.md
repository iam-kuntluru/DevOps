# Design Overview

- **Ansible patching** decides package manager by OS family, upgrades safely, and reboots only when needed.
- **Bash scripts** aim to be idempotent and safe: bulk user ops, controlled permission enforcement, basic monitoring.
- **rsyslog** centralizes logs with per-host files; **logrotate** compresses and retains them.
- No secrets committed. Works great as a portfolio/demo project.
