#!/usr/bin/env bash
set -euo pipefail

STATE_FILE="${1:-./desired_permissions.txt}"

[[ -f "$STATE_FILE" ]] || {
  cat >&2 <<'EOF'
Usage: permissions.sh [state-file]
State file format (owner:group:mode path), e.g.:
  root:adm:0750 /var/myapp
  mysvc:mysvc:0755 /opt/myapp
EOF
  exit 1
}

while IFS= read -r line; do
  [[ -z "$line" || "$line" =~ ^# ]] && continue
  IFS=' ' read -r meta path <<<"$line"
  IFS=':' read -r owner group mode <<<"$meta"

  sudo install -d -o "$owner" -g "$group" -m "$mode" "$path"
  echo "Ensured $path owner=$owner:$group mode=$mode"
done < "$STATE_FILE"
