#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  user_mgmt.sh --create --user <name> [--groups g1,g2] [--shell /bin/bash]
  user_mgmt.sh --lock   --user <name>
  user_mgmt.sh --delete --user <name> [--purge-home]
  user_mgmt.sh -f users.csv --create|--lock|--delete

CSV format (users.csv):
  username,groups(optional),shell(optional)
Example:
  alice,wheel,/bin/bash

Notes:
- Requires sudo for system changes.
- Idempotent: safe to run multiple times.
EOF
}

CSV_FILE=""
ACTION=""
USERNAME=""
GROUPS=""
SHELL_BIN="/bin/bash"
PURGE_HOME=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --create|--lock|--delete) ACTION="${1#--}"; shift ;;
    --user) USERNAME="$2"; shift 2 ;;
    --groups) GROUPS="$2"; shift 2 ;;
    --shell) SHELL_BIN="$2"; shift 2 ;;
    --purge-home) PURGE_HOME=1; shift ;;
    -f|--file) CSV_FILE="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown arg: $1"; usage; exit 1 ;;
  esac
done

[[ -n "$ACTION" ]] || { echo "Choose one: --create|--lock|--delete" ; exit 1; }

create_user() {
  local u="$1" g="$2" sh="$3"
  if id "$u" &>/dev/null; then
    echo "User $u exists; ensuring settings..."
    [[ -n "$g" ]] && sudo usermod -aG "$g" "$u"
    [[ -n "$sh" ]] && sudo chsh -s "$sh" "$u"
  else
    sudo useradd -m -s "$sh" "$u"
    [[ -n "$g" ]] && sudo usermod -aG "$g" "$u"
    echo "Created $u"
  fi
}

lock_user() {
  local u="$1"
  if id "$u" &>/dev/null; then
    sudo usermod -L "$u"
    echo "Locked $u"
  else
    echo "User $u not found; skipping"
  fi
}

delete_user() {
  local u="$1" purge="$2"
  if id "$u" &>/dev/null; then
    if [[ "$purge" -eq 1 ]]; then
      sudo userdel -r "$u"
    else
      sudo userdel "$u"
    fi
    echo "Deleted $u"
  else
    echo "User $u not found; skipping"
  fi
}

process_line() {
  local line="$1"
  IFS=',' read -r u g sh <<<"$line"
  g="${g:-}"
  sh="${sh:-$SHELL_BIN}"
  case "$ACTION" in
    create) create_user "$u" "$g" "$sh" ;;
    lock)   lock_user "$u" ;;
    delete) delete_user "$u" "$PURGE_HOME" ;;
  esac
}

if [[ -n "$CSV_FILE" ]]; then
  while IFS= read -r line; do
    [[ -z "$line" || "$line" =~ ^# ]] && continue
    process_line "$line"
  done < "$CSV_FILE"
else
  [[ -z "$USERNAME" ]] && { echo "--user is required without CSV"; exit 1; }
  process_line "$USERNAME,$GROUPS,$SHELL_BIN"
fi
