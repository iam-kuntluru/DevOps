#!/usr/bin/env bash
set -euo pipefail

# Thresholds (override via env)
CPU_WARN=${CPU_WARN:-85}
MEM_WARN=${MEM_WARN:-85}
DISK_WARN=${DISK_WARN:-90}

hostname="$(hostname)"
log() { logger -t sysmonitor "$*"; echo "$*"; }

# CPU percentage (approx) based on 1-minute load / CPU count
load1=$(awk '{print $1}' /proc/loadavg)
cpu_count=$(nproc 2>/dev/null || echo 1)
cpu_pct=$(awk -v l="$load1" -v c="$cpu_count" 'BEGIN{ printf "%d", (l/c)*100 }')

# Memory percentage used
mem_total=$(grep -i MemTotal /proc/meminfo | awk '{print $2}') # kB
mem_avail=$(grep -i MemAvailable /proc/meminfo | awk '{print $2}') # kB
mem_used_pct=$(( ( (mem_total - mem_avail) * 100 ) / mem_total ))

# Disk usage on /
disk_used_pct=$(df -P / | awk 'NR==2{print $5}' | tr -d '%')

warned=0
if (( cpu_pct >= CPU_WARN )); then
  log "WARN $hostname CPU=${cpu_pct}% >= ${CPU_WARN}%"
  warned=1
fi
if (( mem_used_pct >= MEM_WARN )); then
  log "WARN $hostname MEM=${mem_used_pct}% >= ${MEM_WARN}%"
  warned=1
fi
if (( disk_used_pct >= DISK_WARN )); then
  log "WARN $hostname DISK=${disk_used_pct}% >= ${DISK_WARN}% on /"
  warned=1
fi

if (( warned == 0 )); then
  log "OK $hostname CPU=${cpu_pct}% MEM=${mem_used_pct}% DISK=${disk_used_pct}%"
fi
